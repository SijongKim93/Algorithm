import UIKit

let stock: Int? = nil
print(stock)

let str: String = "Swift"
// non-optional Type
// ㄴ 항상 값을 가지고 있어야 하는 타입이므로 nil은 사용할 수 없다.

let optionalStr: String? = nil
// optional Type 이므로 값이 없어도 된다. 즉 nil을 사용할 수 있다

let a: Int? = nil
let b = a

let c: Optional<Int> = nil
// 위 Optionl 타입과 동일한 구조


//Unwrapping == 값을 추출한다.

var num: Int? = nil
print(num)

num = 123
print(num)

let n = 123
print(n)

// OptionalExpression!   < !을 붙이면 강제로 값을 출력

print(num)
print(num!)

num = nil
//print(num!)
// nil에서 강제 추출하게 되면 에러가 발생하므로 !은 필요할때만 조심스럽게 사용해야한다.

if num != nil {
    print(num!)
}

